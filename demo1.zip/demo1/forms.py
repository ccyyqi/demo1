from models import UserModel
import wtforms
from wtforms.validators import Length, EqualTo, InputRequired
from exts import db
from wtforms import Form
from wtforms import StringField



class RegisterForm(wtforms.Form):
    username = wtforms.StringField(validators=[Length(min=3, max=20, message="用户名格式错误！")])
    password = wtforms.StringField(validators=[Length(min=6, max=20, message="密码格式错误！")])
    role_input = wtforms.StringField(validators=[Length(min=1, max=20)])
    appid = wtforms.StringField(validators=[Length(min=0, max=20)])
    secret = wtforms.StringField(validators=[Length(min=0, max=20)])
    password_confirm = wtforms.StringField(validators=[EqualTo("password", message="两次密码不一致！")])

    # 自定义验证，验证用户名是否注册
    def validate_username(self,field):
        username = field.data
        if field.data[0].isdigit():
            raise wtforms.ValidationError(message="用户名不能以数字开头！")
        user = UserModel.query.filter_by(username = username).first()
        if user:
            raise wtforms.ValidationError(message="该用户名已经被注册！")

    # 自定义验证，验证APPID是否存在
    def validate_appid(self,field):
        appid = field.data
        print(appid)
        if appid == '-':
            return
        user = UserModel.query.filter_by(appid = appid).first()
        if user:
            raise wtforms.ValidationError(message="该appid已经存在！")

class EditUserForm(wtforms.Form):
    username = wtforms.StringField(validators=[Length(min=3, max=20, message="用户名格式错误！")])
    password = wtforms.StringField(validators=[Length(min=0, max=20, message="密码格式错误！")])
    role_input = wtforms.StringField(validators=[Length(min=1, max=20)])
    appid = wtforms.StringField(validators=[Length(min=0, max=20)])
    secret = wtforms.StringField(validators=[Length(min=0, max=20)])
    def validate_username(self,field):
        username = field.data
        if field.data[0].isdigit():
            raise wtforms.ValidationError(message="用户名不能以数字开头！")



class LoginForm(wtforms.Form):
    username = wtforms.StringField(validators=[Length(min=3, max=20, message="用户名格式错误！")])
    password = wtforms.StringField(validators=[Length(min=6, max=20, message="密码格式错误！")])


class AddIPForm(wtforms.Form):
    type = wtforms.StringField(validators=[Length(min=3, max=10, message="type格式错误！")])
    model = wtforms.StringField(validators=[Length(min=3, max=5, message="model格式错误！")])
    subnet = wtforms.StringField(validators=[Length(min=1, max=25, message="subnet格式错误！")])
    gateway = wtforms.StringField(validators=[Length(min=0, max=10, message="gateway格式错误！")])
    mask = wtforms.StringField(validators=[Length(min=0, max=5, message="mask格式错误！")])
    area = wtforms.StringField(validators=[Length(min=0, max=5, message="area格式错误！")])
    location = wtforms.StringField(validators=[Length(min=0, max=5, message="location格式错误！")])
    manager = wtforms.StringField(validators=[Length(min=0, max=5, message="manager格式错误！")])
    description = wtforms.StringField(validators=[Length(min=0, max=5, message="description格式错误！")])





