import json
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, jsonify
import config
from exts import db
from models import UserModel, IPModel, RoleModel
from flask_migrate import Migrate
from forms import RegisterForm, LoginForm, AddIPForm, EditUserForm
from werkzeug.security import generate_password_hash, check_password_hash
from decorators import login_required, permission_required, role_required, get_error_string
from itsdangerous import TimedSerializer as Serializer
from itsdangerous import BadSignature, SignatureExpired
from flask_paginate import get_page_parameter, Pagination
from sqlalchemy import or_, and_, not_

from flask_wtf.csrf import CSRFProtect
csrf = CSRFProtect()


app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.config.from_object(config)
db.init_app(app)


migrate = Migrate(app, db)

def generate_auth_token(data, expires_in=3600):
    s = Serializer(app.config['SECRET_KEY'])
    return s.dumps(data)
def verify_auth_token(user, token, operation):
    s = Serializer(app.config['SECRET_KEY'])
    try:
        data = s.loads(token)
    except SignatureExpired as e:
        return None  # valid token, but expired
    except BadSignature as e:
        return None  # invalid token
    return data

@app.route("/")
def index():
    return render_template("login.html")

# 登录视图函数
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        form = LoginForm(request.form)
        if form.validate():
            username = form.username.data
            password = form.password.data
            user = UserModel.query.filter_by(username=username).first()
            if not user:
                flash("用户名不存在")
                return redirect(url_for("login"))
            if check_password_hash(user.password, password):
                session['user_id'] = user.id
                session['permission'] = ':'.join([power.code for role in user.role for power in role.power])
                session['username'] = user.username
                token = generate_auth_token(username)
                return jsonify({"code": 200, "error": ""})
            else:
                return jsonify({"code": 401, "error": "用户名或密码错误"})
        else:
            return jsonify({"code": 401, "error": "用户名或密码错误"})

@app.route("/IPManagement")
@login_required
def IPManagement():
    page = request.args.get('page', 1, type=int)
    pagination = IPModel.query.order_by(IPModel.id.desc()).paginate(page=page, per_page=15, error_out=False)
    ip_tables=pagination.items
    return render_template("IPManagement.html", ip_tables=ip_tables, pagination=pagination)


@app.route("/search_ip/", methods=['GET'])
# @permission_required('search_ip')
def search_ip():
    type = request.args.get("type",'')
    model = request.args.get("model",'')
    subnet = request.args.get("subnet",'')
    page = request.args.get('page', 1, type=int)
    query = IPModel.query
    if type and model:
        query = query.filter(and_(IPModel.type==type,IPModel.model==model))
    if model:
        query = query.filter(IPModel.model==model)
    if subnet:
        query = query.filter(IPModel.subnet == str(subnet))
    pagination = query.paginate(page=page, per_page=15, error_out=False)
    ip_tables = pagination.items
    params = {'pagination':pagination, 'subnet':subnet, 'type':type,'model':model}
    return render_template("search_ip.html", ip_tables=ip_tables, **params)


@app.route("/add_ip", methods=['POST','GET'])
def add_ip():
    if request.method == 'POST':
        form = AddIPForm(request.form)
        if form.validate():
            type = form.type.data
            model = form.model.data
            subnet = form.subnet.data
            gateway = form.gateway.data
            mask = form.mask.data
            area = form.area.data
            location = form.location.data
            manager = form.manager.data
            description = form.description.data
            ip_table = IPModel(type=type,model=model,subnet=subnet,gateway=gateway,mask=mask,area=area,location=location,manager=manager,description=description)
            db.session.add(ip_table)
            db.session.commit()
            print('IP新增成功')
            return jsonify({"code": 200, "info": "新增IP成功", "error": ""})
        else:
            print(form.errors)
            return jsonify({"code": 401,  "error": "输入信息有错"})
    else:
        return render_template("IPManagement.html")


@app.route("/edit_ip/<int:ip_id>", methods=['POST','GET'])
def edit_ip(ip_id):
    if request.method == 'POST':
        ip_table = db.session.get(IPModel, ip_id)
        if not ip_table:
            return jsonify({'message': 'IP not found'}), 404
        ip_table.type = request.form.get('type')
        ip_table.model = request.form.get('model')
        ip_table.subnet = request.form.get('subnet')
        ip_table.gateway = request.form.get('gateway')
        ip_table.mask = request.form.get('mask')
        ip_table.area = request.form.get('area')
        ip_table.location = request.form.get('location')
        ip_table.manager = request.form.get('manager')
        ip_table.description = request.form.get('description')
        db.session.commit()
        ip_dict = ip_table.IP_to_dict()
        ip_table=json.dumps(ip_dict)
        return jsonify(ip_table)
    else:
        ip_table = db.session.get(IPModel, ip_id)
        if not ip_table:
            return jsonify({"code": 404,  "error": "ip不存在"})
        ip_dict = ip_table.IP_to_dict()
        ip_table = json.dumps(ip_dict)
        return jsonify(ip_table)


@app.route("/delete_ip/<int:ip_id>")
def delete_ip(ip_id):
    ip = db.session.get(IPModel,ip_id)
    # ip_id = request.args.get('ip_id')   # ip= IPModel.query.get(ip_id)
    db.session.delete(ip)  #物理删除,数据库中也没有这条数据了
    db.session.commit()
    return redirect(url_for("IPManagement"))

@app.route("/admin")
@login_required
@permission_required('admin')
def admin():
    page = request.args.get('page', 1, type=int)
    pagination = UserModel.query.order_by(UserModel.join_time.desc()).paginate(page=page, per_page=10, error_out=False)
    users = pagination.items    #users数据类型是一个列表
    return render_template("admin.html", users=users, pagination=pagination)

@app.route("/register", methods=['GET', 'POST'])
@permission_required('register')
def register():
    if request.method == 'GET':
        return render_template("admin.html")
    else:
        form = RegisterForm(request.form)
        if form.validate():
            username = form.username.data
            password = form.password.data
            role_input = form.role_input.data
            api_input = request.form.get('api_input')     #api_input被选中时状态为on，没被选中时状态为None
            if api_input == 'on':
                appid = form.appid.data
                secret = form.secret.data
            else:
                appid, secret = '-', '-'
            user = UserModel(username=username, password=generate_password_hash(password), role_input=role_input, appid=appid, secret=secret)
            db.session.add(user)
            if role_input == 'level1':
                user.role.append(RoleModel.query.get(1))
            else:
                user.role.append(RoleModel.query.get(2))
            db.session.commit()
            return jsonify({"code": 200, "info": "注册用户成功"})
        else:
            error_string = get_error_string(form)
            return jsonify({"code": 401, "error": error_string})


# 登出视图函数
@app.route('/logout')
@login_required
def logout():
    session.clear()
    session.pop('username', None)
    return redirect(url_for("login"))

@app.route("/edit_user/<int:user_id>", methods=['POST','GET'])
def edit_user(user_id):
    if request.method == 'POST':
        user = db.session.get(UserModel, user_id)
        user.username = request.form.get('username')
        user.role_input = request.form.get('role_input')
        user.appid = request.form.get('appid')
        user.secret = request.form.get('secret')
        password = request.form.get('password')
        if password:
            user.set_password(password)
        db.session.commit()
        user_dict = user.User_to_dict()
        user = json.dumps(user_dict)
        return jsonify(user)
    else:
        user = db.session.get(UserModel, user_id)
        if not user:
            return jsonify({"code": 401,  "error": "user不存在"})
        user_dict = user.User_to_dict()
        user = json.dumps(user_dict)
        return jsonify(user)


@app.route("/delete_user/<int:user_id>")
def delete_user(user_id):
    user = db.session.get(UserModel, user_id)
    db.session.delete(user)
    db.session.commit()
    # return jsonify({"code": 200,"info":"删除成功"})
    return redirect(url_for("admin"))

@app.route("/search_user", methods=['GET'])
def search_user():
    searchUser = request.args.get("searchUser")
    field = request.args.get("field")
    per_page = 10
    page = request.args.get('page', 1, type=int)
    query = UserModel.query
    if field == "username":
        query = query.filter(UserModel.username == str(searchUser))
    elif field == "role_input":
        query = query.filter(UserModel.role_input.contains(searchUser))
    elif field == "appid":
        query = query.filter(UserModel.appid == str(searchUser))
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    users = pagination.items
    params = {'pagination':pagination,'searchUser':searchUser,'field':field}
    return render_template("search_user.html", users=users, **params)


@app.cli.command()
def create():
    db.drop_all()
    db.create_all()
    import models
    user = models.UserModel(
        username='admin',
        password=generate_password_hash('123456'),
        role_input='level3',
    )
    db.session.add(user)
    roles = [
        {'name': '普通用户', 'code': 'level1'},
        {'name': '管理员', 'code': 'level2'},
        {'name': '超级管理员', 'code': 'level3'}
    ]
    role1 = models.RoleModel(name=roles[0]['name'], code=roles[0]['code'])
    role2 = models.RoleModel(name=roles[1]['name'], code=roles[1]['code'])
    role3 = models.RoleModel(name=roles[2]['name'], code=roles[2]['code'])
    db.session.add_all([role1, role2, role3])    #将实例对象中的参数插入到数据库中
    _permission = {
        'search_ip': 'search_ip',
        'admin': 'admin'
    }
    power1 = models.PowerModel(code='search_ip', url=_permission['search_ip'])
    power2 = models.PowerModel(code='register', url=_permission['register'])
    power3 = models.PowerModel(code='admin', url=_permission['admin'])
    db.session.add(power1)
    db.session.add(power2)
    db.session.add(power3)

    role1.power.append(power1)
    role2.power.append(power1)

    role3.power.extend([power1, power2, power3])

    user.role.append(role3)    #给当前用户赋予超级管理员的角色
    print(f'Created admin user: {user.username}')
    print('User permissions:', [power.code for role in user.role for power in role.power])
    db.session.commit()

# 两个钩子函数
@app.before_request
def my_before_request():
    user_id = session.get("user_id")
    if user_id:
        user = db.session.get(UserModel, user_id)
        setattr(g, "user", user)
    else:
        setattr(g, "user", None)

# 上下文处理器,显示当前登录的用户名
@app.context_processor
def my_context_processor():
    return {"user": g.user}

if __name__ == '__main__':
    app.run(host ='10.219.255.219', port = 5000, debug=True)