from exts import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash



class UserModel(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), nullable=False, unique = True)
    password = db.Column(db.String(200), nullable=False)
    role_input = db.Column(db.String(100))
    appid = db.Column(db.String(100))
    secret = db.Column(db.String(100))
    join_time = db.Column(db.DateTime, default=datetime.now)
    role = db.relationship('RoleModel', secondary="rt_user_role", backref=db.backref('user'), lazy='dynamic')

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def User_to_dict(self):
        return {
            'code':200,'id': self.id, 'username': self.username, 'role_input': self.role_input, 'appid': self.appid, 'secret': self.secret
        }

class IPModel(db.Model):
    __tablename__ = "ip_table"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    type = db.Column(db.String(100), comment = 'IP段类型')
    model = db.Column(db.String(100), comment = '网段模式')
    subnet = db.Column(db.String(100), comment = '子网IP段')
    gateway = db.Column(db.String(100), comment = '网关')
    mask = db.Column(db.String(100), comment = '子网掩码')
    area = db.Column(db.String(100), comment = '城市所在地区')
    location = db.Column(db.String(200), comment = '具体地点')
    manager = db.Column(db.String(100), comment = '负责人')
    description = db.Column(db.String(200), comment = '业务描述')

    def IP_to_dict(self):
        return {
            'id': self.id, 'type': self.type, 'model': self.model, 'subnet': self.subnet, 'gateway': self.gateway,
            'mask': self.mask,'area': self.area, 'location': self.location, 'manager': self.manager, 'description': self.description
        }

#角色表
class RoleModel(db.Model):
    __tablename__ = "role"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(64), unique = True, comment = '角色名称')
    code = db.Column(db.String(64), unique = True, comment = '角色标识')
    power = db.relationship('PowerModel', secondary = "rt_role_power", backref = db.backref('role'))

# 权限路径表
class PowerModel(db.Model):
    __tablename__ = "power"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    url = db.Column(db.String(64), unique = True, comment = '权限路径')
    code = db.Column(db.String(64), comment = '权限标识')

    parent_id = db.Column(db.Integer, db.ForeignKey("power.id"), comment = '父类编号')
    parent = db.relationship("PowerModel", remote_side = [id])   #自关联

# 创建中间件的关系表
user_role = db.Table(
    "rt_user_role",
    db.Column("id", db.Integer, primary_key=True, autoincrement=True, comment = '标识'),
    db.Column("user_id", db.Integer, db.ForeignKey("user.id"), comment = '用户编号'),
    db.Column("role_id", db.Integer, db.ForeignKey("role.id"), comment = '角色编号')
)

role_power = db.Table(
    "rt_role_power",
    db.Column("id", db.Integer, primary_key=True, autoincrement=True, comment = '标识'),
    db.Column("power_id", db.Integer, db.ForeignKey("power.id"), comment = '用户编号'),
    db.Column("role_id", db.Integer, db.ForeignKey("role.id"), comment = '角色编号')
)
