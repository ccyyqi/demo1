
$(document).ready(function() {
  $('a.type').click(function() {
    var text = $(this).text();
    $('input[name="type"]').val(text);
  });

   $('a.model').click(function() {
    var text = $(this).text();
    $('input[name="model"]').val(text);
  });

  $('.type-div a').click(function() {
    $('.type-div').removeClass('active');
    $(this).parent().addClass('active');
  });
  $('.model-div a').click(function() {
    $('.model-div').removeClass('active');
    $(this).parent().addClass('active');
  });

  $('.resetBtn').click(function() {
    $('#IPForm input[type="text"]').val('');
    $('.type-div').removeClass('active');
    $('.model-div').removeClass('active');
  });

  $('.AddIP-Btn').click(function() {
    $('#addIPModal').modal('show');
  });
  $('#addIPModal .addModal-closeBtn').click(function() {
    $('#addIPModal').modal('hide');
  });

  $('#addIPModal .addModal-addBtn').click(function(event) {
    event.preventDefault();
    const formData = $('.add-form').serialize();
    $.ajax({
      url: '/add_ip',
      type: 'POST',
      data: formData,
      success: function(data) {
        if (data['code'] == 200)
        {
            alert(data['info']);
            window.location.href = '/IPManagement';
            $('#addIPModal').modal('hide');
        }
         else {
            var error = data['error'];
            $("#error").html(error);
            $("#error").show();
        }
      },
      error: function(error) {
        console.error(error);
      }
    });
  });

//  编辑ip弹框的显示和隐藏
  $('#ipList').on('click', function(event) {
    if ($(event.target).hasClass('edit')) {
      event.preventDefault();
      var ip_id = $(event.target).data('ip-id');
      $('#editIPModal').modal('show');
      $.ajax({
        url: '/edit_ip/'+ip_id,
        type: 'GET',
        success: function(response) {
          var ip_table = JSON.parse(response);
          $('.editIP-form input').each(function() {
                const fieldName = $(this).attr('name');
                $(this).val(ip_table[fieldName]);  // 根据 name 属性设置对应的值
              });
        },
        error: function(error) {
          console.error(error);
        }
      });
    }
  });

  $('.editIP-btn').on('click', function(event) {
    event.preventDefault();
    const formData = $('.editIP-form').serialize({ hash: true, empty: true});
    const ip_id = $('.id').val();
    $.ajax({
      url: '/edit_ip/'+ip_id,
      type: 'POST',
      data: formData,
      success: function(response) {
        var ip_table = JSON.parse(response);
        $('tr[data-ip-id="'+ip_id+'"] td').each(function() {
            const className = $(this).attr('class');
            $(this).text(ip_table[className]);
        });
        $('#editIPModal').modal('hide');
      },
      error: function(error) {
        console.error(error);
      }
    });
  });
   $('.editModal-closeBtn').on('click', function(event) {
      event.preventDefault();
      $('#editIPModal').modal('hide');
   });


});




//    function updatePagination(total, total_pages, current_page) {
//        const paginationHtml = [];
//        for (let i = 1; i <= total_pages; i++) {
//            const active = i === current_page ? 'active' : '';
//            paginationHtml.push(`<li class="page-item ${active}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`);
//        }
//        const htmlStr = `<nav aria-label="Page navigation">
//            <ul class="pagination">
//                ${paginationHtml.join('')}
//            </ul>
//            </nav>`;
//        alert(11)
//        $('.pagination').html(htmlStr);
//    }
//
////  搜索ip分页展示结果
//    $('.searchBtn').click(function(event) {
//        event.preventDefault();
//        const IPForm = $('#IPForm').serialize();
//        $.ajax({
//            url: '/search_ip',
//            type: 'GET',
//            data: IPForm,
//            success: function(response) {
//                const data = response.data || [];
//                const htmlStr = $.map(data, (item, index) => {
//                  return `<tr>
//                        <td>${item.type || ''}</td>
//                        <td>${item.model || ''}</td>
//                        <td>${item.subnet || ''}</td>
//                        <td>${item.gateway || ''}</td>
//                        <td>${item.mask || ''}</td>
//                        <td>${item.area || ''}</td>
//                        <td>${item.location || ''}</td>
//                        <td>${item.manager || ''}</td>
//                        <td>${item.description || ''}</td>
//                        <td><a href="{{url_for('edit_ip', ip_id = ip_table.id)}}" class="edit" id="edit-btn" >编辑</a>
//                            <a href="{{url_for('delete_ip', ip_id = ip_table.id)}}" class="del" id="delete-btn" onclick="return confirm('你确定要删除吗？');">删除</a></td>
//                        </tr>`
//                }).join('')
//                $('#ip-results').append(htmlStr);
//
//                const total = response.total || 0;
//                const total_pages = response.total_pages || 0;
//                const current_page = response.current_page || 1;
//                updatePagination(total, total_pages, current_page);
//            },
//                error: function(error) {
//                console.error(error);
//            }
//        });
//    });






