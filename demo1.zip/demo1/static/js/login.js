 $(document).ready(function() {
     $("#submit").click(function (event) {
         event.preventDefault();
         const csrfToken = $('meta[name=csrf-token]').attr('content');
         var username = $('input[name="username"]').val();
         var password = $("input[name='password']").val();
         $.post({
             url: '/login',
             headers: {'X-CSRFToken': csrfToken},
             data: {
                 'username': username,
                 'password': password
             },
             success: function (data) {
                if (data['code'] == 200) {
                    window.location.href = '/IPManagement'
                } else {
                    var error = data['error'];
                    $("#error").html(error);
                    $("#error").show();
                }
             },
             error: function(error) {
                 console.error(error);
             }
         });
     });
 });