
$(document).ready(function() {
   $('#apiCheckbox').click(function() {
    if ($(this).is(':checked')) {
        $('.apiInput').removeClass('hidden');
        }
    else {
        $('.apiInput').addClass('hidden');
        }
    });

    $('#myButton').click(function() {
        const randomNum = Math.floor(Math.random() * 1000000000);
        $('.secretInput').val(randomNum);
    });

    $('#user-AddBtn').click(function() {
        $('#addUserModal').modal('show');
    });
    $('#addUserModal .adduser-closeBtn').click(function() {
        $('#addUserModal').modal('hide');
    });

  $('#addUserModal .adduser-addBtn').click(function(event) {
        event.preventDefault();
        const formData = $('.adduser-form').serialize();
        $.ajax({
            url: '/register',
            type: 'POST',
            data: formData,
            success: function(data) {
            if (data['code'] == 200)
            {
                alert(data['info']);
                window.location.href = '/admin';
                $('#addIPModal').modal('hide');
            }
             else {
                var error = data['error'];
                $("#add-error").html(error);
                $("#add-error").show();
            }
            },
                error: function(error) {
                console.error(error);
            }
        });
  });

//    编辑弹框的显示和隐藏
    $('#updatePassword').on('click', function(event) {
      if ($(this).prop('checked')) {
        $('.passwordInput').removeClass('hidden');
      }
      else {
        $('.passwordInput').addClass('hidden');
      }
    });
    $('#editApi-Checkbox').on('click', function(){
      if ($(this).prop('checked')) {
        $('.apiInput').removeClass('hidden');
      }
      else {
        $('.apiInput').addClass('hidden');
      }
    });
//获取想要编辑的用户id以及其他信息，回填到编辑弹框中
    $('.userList').on('click', function(event) {
        if ($(event.target).hasClass('edit')) {
          event.preventDefault();
          var userId = $(event.target).data('user-id');
          $('#editUserModal').modal('show');
          $.ajax({
            url: '/edit_user/'+userId,
            type: 'GET',
            success: function(response) {
              var user = JSON.parse(response);
              $('.edit-form input').each(function() {
                const fieldName = $(this).attr('name');
                $(this).val(user[fieldName]);  // 根据 name 属性设置对应的值
              });
            },
            error: function(error) {
              console.error(error);
            }
          });
        }
    });

    $('.edit-btn').on('click', function(event) {
        event.preventDefault();
        const formData = $('.edit-form').serialize({ hash: true, empty: true});
        const userId = $('.id').val();
        $.ajax({
          url: '/edit_user/'+userId,
          type: 'POST',
          data: formData,
          success: function(response) {
            var user = JSON.parse(response);
            $('tr[data-user-id="'+userId+'"] td').each(function() {
                const className = $(this).attr('class');
                $(this).text(user[className]);
            })
            $('#editUserModal').modal('hide');
          },
          error: function(error) {
            console.error(error);
          }
        });
    });
    $('.editUser-closeBtn').click(function() {
       $('#editUserModal').modal('hide');
    });

//删除用户接口
//    $('.userList').on('click', function(event) {
//        if ($(event.target).hasClass('del')) {
//          event.preventDefault();
//          var userId = $(event.target).data('user-id');
//          $.ajax({
//            url: '/delete_user/'+userId,
//            type: 'GET',
//            success: function(response) {
//              window.location.href = '/admin'
//            },
//            error: function(error) {
//              console.error(error);
//            }
//          });
//        }
//    });

});




