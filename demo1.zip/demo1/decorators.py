from functools import wraps
from flask import g, redirect, url_for, session, abort

def login_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if g.user:
            return func(*args, **kwargs)
        else:
            abort(403)
    return inner


# 权限校验
def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # print('permission', permission, session.get('permission', ''))
            if permission not in session.get('permission', ''):
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# 角色校验
def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            role_code = [_role.code for _role in g.user.role]
            print('role', role, role_code)
            if role not in role_code:
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def admin_required(f):
    return role_required('level3')(f)

def get_error_string(form):
    error_messages = []
    for key, value in form.errors.items():
        for i in value:
            error_messages.append(i)
    error_string = ' '.join(error_messages)
    return error_string